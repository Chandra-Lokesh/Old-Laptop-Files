package com.ust.traineeapp;

import com.ust.traineeapp.model.Trainee;
import com.ust.traineeapp.repository.TraineeRepository;
import com.ust.traineeapp.repository.TraineeRepositoryImpl;
import com.ust.traineeapp.util.JdbcConnectionUtil;

import java.time.LocalDate;
import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

//        Trainee trainee = new Trainee(0, "world", "mumbai", LocalDate.of(2004, 02, 19));
        TraineeRepository traineeRepository = new TraineeRepositoryImpl();
//        traineeRepository.save(trainee);
        traineeRepository.getAllTrainees().forEach(System.out::println);
        System.out.println(traineeRepository.getTrainee(9));
        traineeRepository.deleteTrainee(11);
        traineeRepository.getAllTrainees().forEach(System.out::println);

    }
}