package com.ust.traineeapp.repository;

import com.mysql.cj.protocol.Resultset;
import com.ust.traineeapp.model.Trainee;
import com.ust.traineeapp.util.JdbcConnectionUtil;

import javax.xml.transform.Result;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TraineeRepositoryImpl implements TraineeRepository{

    Connection connection;

    public TraineeRepositoryImpl(){
        connection = JdbcConnectionUtil.createConnection();
    }
    @Override
    public Trainee save(Trainee trainee) {
//        String sql = "insert into trainee(name, location, date_joined) values ('%s', '%s', '%s')"
//                .formatted(trainee.name(), trainee.location(), trainee.date_joined().toString());
        String sql = "insert into trainee(name, location, date_joined) values (?,?,?)";

        try{
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, trainee.name());
            preparedStatement.setString(2, trainee.location());
//            preparedStatement.setString(3, trainee.date_joined().toString());
            preparedStatement.setString(3, trainee.date_joined().toString());
//            Statement statement = connection.createStatement();
//            int rowCount = statement.executeUpdate(sql);
            int rowCount = preparedStatement.executeUpdate();
            System.out.println(rowCount + " rows inserted");
        } catch (SQLException e){
            throw new RuntimeException(e);
        }

        return trainee;

    }

    @Override
    public Trainee getTrainee(int id) {
        String sql = "select * from trainee where id=" + id;
        String name="", location="";
        LocalDate date_joined = null;
        try {
            ResultSet resultSet = connection.createStatement().executeQuery(sql);
            while(resultSet.next()){
                name = resultSet.getString("name");
                location = resultSet.getString("location");
                date_joined = resultSet.getDate("date_joined").toLocalDate();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return new Trainee(id, name, location, date_joined);
    }

    @Override
    public List<Trainee> getAllTrainees() {
        String sql = "select * from trainee";
        List<Trainee> trainees = new ArrayList<>();
        try{
            Statement statement = connection.createStatement();
            ResultSet resultset = statement.executeQuery(sql);
            if(resultset == null)
                return null;
            while(resultset.next()){
                int id = resultset.getInt("id");
                String name = resultset.getString("name");
                String location = resultset.getString("location");
                LocalDate date_joined = resultset.getDate("date_joined").toLocalDate();
                trainees.add(new Trainee(id, name, location, date_joined));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return trainees;
    }

    @Override
    public void deleteTrainee(int id) {

        String sql = "delete from trainee where id = " + id;
        try {
            connection.createStatement().execute(sql);
            System.out.println("Delete Successful!");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
