package com.ust.traineeapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcConnectionUtil {

//    private static final String url = "jdbc:mysql://localhost:3307/ust_db";
    private static final String url = "jdbc:sqlserver://localhost:1433/ust_db";
    private static final String username = "root";
    private static final String password = "password";

    public static Connection createConnection(){
        try{
            Connection connection = DriverManager.getConnection(url, username, password);
            return connection;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
